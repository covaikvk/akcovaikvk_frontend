// FavouritesContext.js
import React, { createContext, useContext, useState, useEffect } from "react";

const FavouritesContext = createContext();

export const FavouritesProvider = ({ children }) => {
  const [favourites, setFavourites] = useState([]); // ✅ Always an array

  // ✅ Fetch favourites safely
  const fetchFavourites = async () => {
    try {
      const response = await fetch("https://kvk-backend.onrender.com/api/favourites");

      // Read raw text first
      const text = await response.text();
      console.log("API raw response:", text); // Debug: see what API returns

      // Try parsing JSON
      let data;
      try {
        data = JSON.parse(text);
      } catch (err) {
        console.warn("Response not valid JSON, using empty array");
        data = [];
      }

      setFavourites(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching favourites:", error);
      setFavourites([]);
    }
  };

  // ✅ Fetch once on mount
  useEffect(() => {
    fetchFavourites();
  }, []);

  // ✅ Check if an item is favourite
  const isFavourite = (item) => {
    if (!Array.isArray(favourites)) return false;
    return favourites.some((fav) => fav.id === item.id);
  };

  // ✅ Toggle favourite with API sync
  const toggleFavourite = async (item) => {
    try {
      if (isFavourite(item)) {
        // Remove favourite
        await fetch(`https://kvk-backend.onrender.com/api/favourites/${item.id}`, {
          method: "DELETE",
        });
        setFavourites((prev) => prev.filter((fav) => fav.id !== item.id));
      } else {
        // Add favourite
        await fetch("https://kvk-backend.onrender.com/api/favourites", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(item),
        });
        setFavourites((prev) => [...prev, item]);
      }
    } catch (error) {
      console.error("Error toggling favourite:", error);
    }
  };

  return (
    <FavouritesContext.Provider
      value={{
        favourites,
        toggleFavourite,
        isFavourite,
        fetchFavourites, // ✅ Exposed for manual refresh
      }}
    >
      {children}
    </FavouritesContext.Provider>
  );
};

export const useFavourites = () => useContext(FavouritesContext);